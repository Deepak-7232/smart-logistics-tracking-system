package lar.service;

import lar.entity.Driver;
import lar.entity.Shipment;
import lar.repository.DriverRepository;
import lar.repository.ShipmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ShipmentService {

    @Autowired
    private ShipmentRepository shipmentRepository;

    @Autowired
    private DriverRepository driverRepository;

    public Shipment saveShipment(Shipment shipment) {
        return shipmentRepository.save(shipment);
    }

    public List<Shipment> getAllShipments() {
        return shipmentRepository.findAll();
    }

    public Shipment getShipmentByTrackingId(String trackingId) {
        return shipmentRepository.findByTrackingId(trackingId);
    }

    public Shipment updateShipmentStatus(String trackingId, String status) {
        Shipment shipment = shipmentRepository.findByTrackingId(trackingId);
        if (shipment == null) throw new RuntimeException("Shipment not found: " + trackingId);
        shipment.setStatus(status);
        return shipmentRepository.save(shipment);
    }

    /**
     * Assign a Driver entity to a shipment.
     * Validates that the driver is currently available before assignment.
     */
    public Shipment assignDriver(String trackingId, Long driverId) {
        Shipment shipment = shipmentRepository.findByTrackingId(trackingId);
        if (shipment == null) throw new RuntimeException("Shipment not found: " + trackingId);

        // If there's an existing driver, free them up first
        if (shipment.getDriver() != null) {
            Driver oldDriver = shipment.getDriver();
            oldDriver.setAvailable(true);
            oldDriver.setVehicleAssigned(null);
            driverRepository.save(oldDriver);
        }

        if (driverId == null) {
            shipment.setDriver(null);
            return shipmentRepository.save(shipment);
        }

        Driver driver = driverRepository.findById(driverId).orElseThrow(
                () -> new RuntimeException("Driver not found: " + driverId)
        );

        // ── Availability validation (Step 11) ──────────────────────────────
        if (!Boolean.TRUE.equals(driver.getAvailable())) {
            throw new RuntimeException("Driver is not available for assignment");
        }

        shipment.setDriver(driver);
        // Mark driver as unavailable once assigned
        driver.setAvailable(false);
        // Also assign the shipment's vehicle to the driver
        if (shipment.getVehicleAssigned() != null && !shipment.getVehicleAssigned().isEmpty()) {
            driver.setVehicleAssigned(shipment.getVehicleAssigned());
        }
        driverRepository.save(driver);

        return shipmentRepository.save(shipment);
    }

    public Shipment assignVehicle(String trackingId, String vehicleNumber) {
        Shipment shipment = shipmentRepository.findByTrackingId(trackingId);
        if (shipment == null) throw new RuntimeException("Shipment not found: " + trackingId);
        
        String newVehicle = (vehicleNumber != null && vehicleNumber.trim().isEmpty()) ? null : vehicleNumber;
        shipment.setVehicleAssigned(newVehicle);
        
        // If there is a driver assigned to this shipment, update their vehicle too
        if (shipment.getDriver() != null) {
            Driver driver = shipment.getDriver();
            driver.setVehicleAssigned(newVehicle);
            driverRepository.save(driver);
        }
        
        return shipmentRepository.save(shipment);
    }

    /** Returns all shipments assigned to a given driver (by email). */
    public List<Shipment> getShipmentsByDriverEmail(String email) {
        Driver driver = driverRepository.findByEmail(email);
        if (driver == null) throw new RuntimeException("Driver not found: " + email);
        return shipmentRepository.findByDriver(driver);
    }
}